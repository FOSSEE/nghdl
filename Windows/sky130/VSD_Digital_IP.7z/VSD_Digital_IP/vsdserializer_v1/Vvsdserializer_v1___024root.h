// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vvsdserializer_v1.h for the primary calling header

#ifndef VERILATED_VVSDSERIALIZER_V1___024ROOT_H_
#define VERILATED_VVSDSERIALIZER_V1___024ROOT_H_  // guard

#include "verilated_heavy.h"

//==========

class Vvsdserializer_v1__Syms;

//----------

VL_MODULE(Vvsdserializer_v1___024root) {
  public:

    // PORTS
    VL_IN8(clk,0,0);
    VL_IN8(load,0,0);
    VL_OUT8(out,0,0);
    VL_IN16(in,9,0);

    // LOCAL SIGNALS
    SData/*9:0*/ vsdserializer_v1__DOT__tmp;

    // LOCAL VARIABLES
    CData/*0:0*/ __Vclklast__TOP__clk;

    // INTERNAL VARIABLES
    Vvsdserializer_v1__Syms* vlSymsp;  // Symbol table

    // CONSTRUCTORS
  private:
    VL_UNCOPYABLE(Vvsdserializer_v1___024root);  ///< Copying not allowed
  public:
    Vvsdserializer_v1___024root(const char* name);
    ~Vvsdserializer_v1___024root();

    // INTERNAL METHODS
    void __Vconfigure(Vvsdserializer_v1__Syms* symsp, bool first);
} VL_ATTR_ALIGNED(VL_CACHE_LINE_BYTES);

//----------


#endif  // guard
