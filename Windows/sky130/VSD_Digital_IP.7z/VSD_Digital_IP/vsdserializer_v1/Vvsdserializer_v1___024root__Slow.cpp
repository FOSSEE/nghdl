// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vvsdserializer_v1.h for the primary calling header

#include "Vvsdserializer_v1___024root.h"
#include "Vvsdserializer_v1__Syms.h"

//==========


void Vvsdserializer_v1___024root___ctor_var_reset(Vvsdserializer_v1___024root* vlSelf);

Vvsdserializer_v1___024root::Vvsdserializer_v1___024root(const char* _vcname__)
    : VerilatedModule(_vcname__)
 {
    // Reset structure values
    Vvsdserializer_v1___024root___ctor_var_reset(this);
}

void Vvsdserializer_v1___024root::__Vconfigure(Vvsdserializer_v1__Syms* _vlSymsp, bool first) {
    if (false && first) {}  // Prevent unused
    this->vlSymsp = _vlSymsp;
}

Vvsdserializer_v1___024root::~Vvsdserializer_v1___024root() {
}

void Vvsdserializer_v1___024root___eval_initial(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___eval_initial\n"); );
    // Body
    vlSelf->__Vclklast__TOP__clk = vlSelf->clk;
}

void Vvsdserializer_v1___024root___eval_settle(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___eval_settle\n"); );
}

void Vvsdserializer_v1___024root___final(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___final\n"); );
}

void Vvsdserializer_v1___024root___ctor_var_reset(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->clk = VL_RAND_RESET_I(1);
    vlSelf->load = VL_RAND_RESET_I(1);
    vlSelf->in = VL_RAND_RESET_I(10);
    vlSelf->out = VL_RAND_RESET_I(1);
    vlSelf->vsdserializer_v1__DOT__tmp = VL_RAND_RESET_I(10);
}
