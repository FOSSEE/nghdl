// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vvsdserializer_v1.h for the primary calling header

#include "Vvsdserializer_v1___024root.h"
#include "Vvsdserializer_v1__Syms.h"

//==========

VL_INLINE_OPT void Vvsdserializer_v1___024root___sequent__TOP__1(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___sequent__TOP__1\n"); );
    // Variables
    SData/*9:0*/ __Vdly__vsdserializer_v1__DOT__tmp;
    // Body
    __Vdly__vsdserializer_v1__DOT__tmp = vlSelf->vsdserializer_v1__DOT__tmp;
    if (vlSelf->load) {
        __Vdly__vsdserializer_v1__DOT__tmp = vlSelf->in;
    } else {
        vlSelf->out = (1U & ((IData)(vlSelf->vsdserializer_v1__DOT__tmp) 
                             >> 9U));
        __Vdly__vsdserializer_v1__DOT__tmp = (0x3feU 
                                              & ((IData)(vlSelf->vsdserializer_v1__DOT__tmp) 
                                                 << 1U));
    }
    vlSelf->vsdserializer_v1__DOT__tmp = __Vdly__vsdserializer_v1__DOT__tmp;
}

void Vvsdserializer_v1___024root___eval(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___eval\n"); );
    // Body
    if (((IData)(vlSelf->clk) & (~ (IData)(vlSelf->__Vclklast__TOP__clk)))) {
        Vvsdserializer_v1___024root___sequent__TOP__1(vlSelf);
    }
    // Final
    vlSelf->__Vclklast__TOP__clk = vlSelf->clk;
}

QData Vvsdserializer_v1___024root___change_request_1(Vvsdserializer_v1___024root* vlSelf);

VL_INLINE_OPT QData Vvsdserializer_v1___024root___change_request(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___change_request\n"); );
    // Body
    return (Vvsdserializer_v1___024root___change_request_1(vlSelf));
}

VL_INLINE_OPT QData Vvsdserializer_v1___024root___change_request_1(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___change_request_1\n"); );
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vvsdserializer_v1___024root___eval_debug_assertions(Vvsdserializer_v1___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vvsdserializer_v1__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vvsdserializer_v1___024root___eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((vlSelf->clk & 0xfeU))) {
        Verilated::overWidthError("clk");}
    if (VL_UNLIKELY((vlSelf->load & 0xfeU))) {
        Verilated::overWidthError("load");}
    if (VL_UNLIKELY((vlSelf->in & 0xfc00U))) {
        Verilated::overWidthError("in");}
}
#endif  // VL_DEBUG
