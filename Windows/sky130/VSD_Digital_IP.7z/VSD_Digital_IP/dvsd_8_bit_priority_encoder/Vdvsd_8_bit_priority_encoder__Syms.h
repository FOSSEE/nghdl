// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VDVSD_8_BIT_PRIORITY_ENCODER__SYMS_H_
#define VERILATED_VDVSD_8_BIT_PRIORITY_ENCODER__SYMS_H_  // guard

#include "verilated_heavy.h"

// INCLUDE MODEL CLASS

#include "Vdvsd_8_bit_priority_encoder.h"

// INCLUDE MODULE CLASSES
#include "Vdvsd_8_bit_priority_encoder___024root.h"

// SYMS CLASS (contains all model state)
class Vdvsd_8_bit_priority_encoder__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vdvsd_8_bit_priority_encoder* const __Vm_modelp;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vdvsd_8_bit_priority_encoder___024root TOP;

    // CONSTRUCTORS
    Vdvsd_8_bit_priority_encoder__Syms(VerilatedContext* contextp, const char* namep, Vdvsd_8_bit_priority_encoder* modelp);
    ~Vdvsd_8_bit_priority_encoder__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
} VL_ATTR_ALIGNED(VL_CACHE_LINE_BYTES);

#endif  // guard
