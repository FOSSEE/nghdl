// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vdvsd_8_bit_priority_encoder.h for the primary calling header

#include "Vdvsd_8_bit_priority_encoder___024root.h"
#include "Vdvsd_8_bit_priority_encoder__Syms.h"

//==========

VL_INLINE_OPT void Vdvsd_8_bit_priority_encoder___024root___combo__TOP__1(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___combo__TOP__1\n"); );
    // Body
    vlSelf->eno = (1U & (~ ((~ (IData)((0xffU == (IData)(vlSelf->in)))) 
                            & (IData)(vlSelf->en))));
    if (vlSelf->en) {
        if (((((((((0U == (IData)(vlSelf->in)) | (1U 
                                                  == (IData)(vlSelf->in))) 
                  | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                 | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                | (8U == (0xf8U & (IData)(vlSelf->in)))) 
               | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
              | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
             | (0x40U == (0xc0U & (IData)(vlSelf->in))))) {
            if ((0U != (IData)(vlSelf->in))) {
                if ((1U != (IData)(vlSelf->in))) {
                    if ((2U != (0xfeU & (IData)(vlSelf->in)))) {
                        if ((4U == (0xfcU & (IData)(vlSelf->in)))) {
                            vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out3 = 2U;
                        }
                    }
                }
            }
        }
    }
    if (vlSelf->en) {
        if (((((((((0U == (IData)(vlSelf->in)) | (1U 
                                                  == (IData)(vlSelf->in))) 
                  | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                 | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                | (8U == (0xf8U & (IData)(vlSelf->in)))) 
               | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
              | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
             | (0x40U == (0xc0U & (IData)(vlSelf->in))))) {
            if ((0U != (IData)(vlSelf->in))) {
                if ((1U != (IData)(vlSelf->in))) {
                    if ((2U == (0xfeU & (IData)(vlSelf->in)))) {
                        vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out2 = 1U;
                    }
                }
            }
        }
    }
    if (vlSelf->en) {
        if (((((((((0U == (IData)(vlSelf->in)) | (1U 
                                                  == (IData)(vlSelf->in))) 
                  | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                 | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                | (8U == (0xf8U & (IData)(vlSelf->in)))) 
               | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
              | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
             | (0x40U == (0xc0U & (IData)(vlSelf->in))))) {
            if ((0U != (IData)(vlSelf->in))) {
                if ((1U == (IData)(vlSelf->in))) {
                    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out1 = 0U;
                }
            }
        }
    }
    if (vlSelf->en) {
        if (((((((((0U == (IData)(vlSelf->in)) | (1U 
                                                  == (IData)(vlSelf->in))) 
                  | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                 | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                | (8U == (0xf8U & (IData)(vlSelf->in)))) 
               | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
              | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
             | (0x40U == (0xc0U & (IData)(vlSelf->in))))) {
            if ((0U != (IData)(vlSelf->in))) {
                if ((1U != (IData)(vlSelf->in))) {
                    if ((2U != (0xfeU & (IData)(vlSelf->in)))) {
                        if ((4U != (0xfcU & (IData)(vlSelf->in)))) {
                            if ((8U != (0xf8U & (IData)(vlSelf->in)))) {
                                if ((0x10U == (0xf0U 
                                               & (IData)(vlSelf->in)))) {
                                    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out5 = 4U;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (vlSelf->en) {
        if (((((((((0U == (IData)(vlSelf->in)) | (1U 
                                                  == (IData)(vlSelf->in))) 
                  | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                 | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                | (8U == (0xf8U & (IData)(vlSelf->in)))) 
               | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
              | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
             | (0x40U == (0xc0U & (IData)(vlSelf->in))))) {
            if ((0U != (IData)(vlSelf->in))) {
                if ((1U != (IData)(vlSelf->in))) {
                    if ((2U != (0xfeU & (IData)(vlSelf->in)))) {
                        if ((4U != (0xfcU & (IData)(vlSelf->in)))) {
                            if ((8U == (0xf8U & (IData)(vlSelf->in)))) {
                                vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out4 = 3U;
                            }
                        }
                    }
                }
            }
        }
    }
    if (vlSelf->en) {
        if (((((((((0U == (IData)(vlSelf->in)) | (1U 
                                                  == (IData)(vlSelf->in))) 
                  | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                 | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                | (8U == (0xf8U & (IData)(vlSelf->in)))) 
               | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
              | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
             | (0x40U == (0xc0U & (IData)(vlSelf->in))))) {
            if ((0U != (IData)(vlSelf->in))) {
                if ((1U != (IData)(vlSelf->in))) {
                    if ((2U != (0xfeU & (IData)(vlSelf->in)))) {
                        if ((4U != (0xfcU & (IData)(vlSelf->in)))) {
                            if ((8U != (0xf8U & (IData)(vlSelf->in)))) {
                                if ((0x10U != (0xf0U 
                                               & (IData)(vlSelf->in)))) {
                                    if ((0x20U == (0xe0U 
                                                   & (IData)(vlSelf->in)))) {
                                        vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out6 = 5U;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (vlSelf->en) {
        if (((((((((0U == (IData)(vlSelf->in)) | (1U 
                                                  == (IData)(vlSelf->in))) 
                  | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                 | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                | (8U == (0xf8U & (IData)(vlSelf->in)))) 
               | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
              | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
             | (0x40U == (0xc0U & (IData)(vlSelf->in))))) {
            if ((0U != (IData)(vlSelf->in))) {
                if ((1U != (IData)(vlSelf->in))) {
                    if ((2U != (0xfeU & (IData)(vlSelf->in)))) {
                        if ((4U != (0xfcU & (IData)(vlSelf->in)))) {
                            if ((8U != (0xf8U & (IData)(vlSelf->in)))) {
                                if ((0x10U != (0xf0U 
                                               & (IData)(vlSelf->in)))) {
                                    if ((0x20U != (0xe0U 
                                                   & (IData)(vlSelf->in)))) {
                                        vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out7 = 6U;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (vlSelf->en) {
        if ((1U & (~ ((((((((0U == (IData)(vlSelf->in)) 
                            | (1U == (IData)(vlSelf->in))) 
                           | (2U == (0xfeU & (IData)(vlSelf->in)))) 
                          | (4U == (0xfcU & (IData)(vlSelf->in)))) 
                         | (8U == (0xf8U & (IData)(vlSelf->in)))) 
                        | (0x10U == (0xf0U & (IData)(vlSelf->in)))) 
                       | (0x20U == (0xe0U & (IData)(vlSelf->in)))) 
                      | (0x40U == (0xc0U & (IData)(vlSelf->in))))))) {
            if ((0x80U == (0x80U & (IData)(vlSelf->in)))) {
                vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out8 = 7U;
            }
        }
    }
    vlSelf->gs = ((~ (IData)(vlSelf->eno)) & (IData)(vlSelf->en));
    vlSelf->out = ((((((((IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out1) 
                         | (IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out2)) 
                        | (IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out3)) 
                       | (IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out4)) 
                      | (IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out5)) 
                     | (IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out6)) 
                    | (IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out7)) 
                   | (IData)(vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out8));
}

void Vdvsd_8_bit_priority_encoder___024root___eval(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___eval\n"); );
    // Body
    Vdvsd_8_bit_priority_encoder___024root___combo__TOP__1(vlSelf);
}

QData Vdvsd_8_bit_priority_encoder___024root___change_request_1(Vdvsd_8_bit_priority_encoder___024root* vlSelf);

VL_INLINE_OPT QData Vdvsd_8_bit_priority_encoder___024root___change_request(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___change_request\n"); );
    // Body
    return (Vdvsd_8_bit_priority_encoder___024root___change_request_1(vlSelf));
}

VL_INLINE_OPT QData Vdvsd_8_bit_priority_encoder___024root___change_request_1(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___change_request_1\n"); );
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void Vdvsd_8_bit_priority_encoder___024root___eval_debug_assertions(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((vlSelf->en & 0xfeU))) {
        Verilated::overWidthError("en");}
}
#endif  // VL_DEBUG
