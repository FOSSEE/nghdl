// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vdvsd_8_bit_priority_encoder.h"
#include "Vdvsd_8_bit_priority_encoder__Syms.h"

//============================================================
// Constructors

Vdvsd_8_bit_priority_encoder::Vdvsd_8_bit_priority_encoder(VerilatedContext* _vcontextp__, const char* _vcname__)
    : vlSymsp{new Vdvsd_8_bit_priority_encoder__Syms(_vcontextp__, _vcname__, this)}
    , en{vlSymsp->TOP.en}
    , in{vlSymsp->TOP.in}
    , eno{vlSymsp->TOP.eno}
    , gs{vlSymsp->TOP.gs}
    , out{vlSymsp->TOP.out}
    , rootp{&(vlSymsp->TOP)}
{
}

Vdvsd_8_bit_priority_encoder::Vdvsd_8_bit_priority_encoder(const char* _vcname__)
    : Vdvsd_8_bit_priority_encoder(nullptr, _vcname__)
{
}

//============================================================
// Destructor

Vdvsd_8_bit_priority_encoder::~Vdvsd_8_bit_priority_encoder() {
    delete vlSymsp;
}

//============================================================
// Evaluation loop

void Vdvsd_8_bit_priority_encoder___024root___eval_initial(Vdvsd_8_bit_priority_encoder___024root* vlSelf);
void Vdvsd_8_bit_priority_encoder___024root___eval_settle(Vdvsd_8_bit_priority_encoder___024root* vlSelf);
void Vdvsd_8_bit_priority_encoder___024root___eval(Vdvsd_8_bit_priority_encoder___024root* vlSelf);
QData Vdvsd_8_bit_priority_encoder___024root___change_request(Vdvsd_8_bit_priority_encoder___024root* vlSelf);
#ifdef VL_DEBUG
void Vdvsd_8_bit_priority_encoder___024root___eval_debug_assertions(Vdvsd_8_bit_priority_encoder___024root* vlSelf);
#endif  // VL_DEBUG
void Vdvsd_8_bit_priority_encoder___024root___final(Vdvsd_8_bit_priority_encoder___024root* vlSelf);

static void _eval_initial_loop(Vdvsd_8_bit_priority_encoder__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    Vdvsd_8_bit_priority_encoder___024root___eval_initial(&(vlSymsp->TOP));
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial loop\n"););
        Vdvsd_8_bit_priority_encoder___024root___eval_settle(&(vlSymsp->TOP));
        Vdvsd_8_bit_priority_encoder___024root___eval(&(vlSymsp->TOP));
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = Vdvsd_8_bit_priority_encoder___024root___change_request(&(vlSymsp->TOP));
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("dvsd_8_bit_priority_encoder.v", 19, "",
                "Verilated model didn't DC converge\n"
                "- See https://verilator.org/warn/DIDNOTCONVERGE");
        } else {
            __Vchange = Vdvsd_8_bit_priority_encoder___024root___change_request(&(vlSymsp->TOP));
        }
    } while (VL_UNLIKELY(__Vchange));
}

void Vdvsd_8_bit_priority_encoder::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vdvsd_8_bit_priority_encoder::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vdvsd_8_bit_priority_encoder___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        Vdvsd_8_bit_priority_encoder___024root___eval(&(vlSymsp->TOP));
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = Vdvsd_8_bit_priority_encoder___024root___change_request(&(vlSymsp->TOP));
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("dvsd_8_bit_priority_encoder.v", 19, "",
                "Verilated model didn't converge\n"
                "- See https://verilator.org/warn/DIDNOTCONVERGE");
        } else {
            __Vchange = Vdvsd_8_bit_priority_encoder___024root___change_request(&(vlSymsp->TOP));
        }
    } while (VL_UNLIKELY(__Vchange));
}

//============================================================
// Invoke final blocks

void Vdvsd_8_bit_priority_encoder::final() {
    Vdvsd_8_bit_priority_encoder___024root___final(&(vlSymsp->TOP));
}

//============================================================
// Utilities

VerilatedContext* Vdvsd_8_bit_priority_encoder::contextp() const {
    return vlSymsp->_vm_contextp__;
}

const char* Vdvsd_8_bit_priority_encoder::name() const {
    return vlSymsp->name();
}
