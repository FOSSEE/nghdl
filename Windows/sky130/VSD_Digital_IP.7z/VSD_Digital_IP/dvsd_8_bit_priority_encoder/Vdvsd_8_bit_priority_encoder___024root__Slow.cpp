// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vdvsd_8_bit_priority_encoder.h for the primary calling header

#include "Vdvsd_8_bit_priority_encoder___024root.h"
#include "Vdvsd_8_bit_priority_encoder__Syms.h"

//==========


void Vdvsd_8_bit_priority_encoder___024root___ctor_var_reset(Vdvsd_8_bit_priority_encoder___024root* vlSelf);

Vdvsd_8_bit_priority_encoder___024root::Vdvsd_8_bit_priority_encoder___024root(const char* _vcname__)
    : VerilatedModule(_vcname__)
 {
    // Reset structure values
    Vdvsd_8_bit_priority_encoder___024root___ctor_var_reset(this);
}

void Vdvsd_8_bit_priority_encoder___024root::__Vconfigure(Vdvsd_8_bit_priority_encoder__Syms* _vlSymsp, bool first) {
    if (false && first) {}  // Prevent unused
    this->vlSymsp = _vlSymsp;
}

Vdvsd_8_bit_priority_encoder___024root::~Vdvsd_8_bit_priority_encoder___024root() {
}

void Vdvsd_8_bit_priority_encoder___024root___eval_initial(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___eval_initial\n"); );
}

void Vdvsd_8_bit_priority_encoder___024root___combo__TOP__1(Vdvsd_8_bit_priority_encoder___024root* vlSelf);

void Vdvsd_8_bit_priority_encoder___024root___eval_settle(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___eval_settle\n"); );
    // Body
    Vdvsd_8_bit_priority_encoder___024root___combo__TOP__1(vlSelf);
}

void Vdvsd_8_bit_priority_encoder___024root___final(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___final\n"); );
}

void Vdvsd_8_bit_priority_encoder___024root___ctor_var_reset(Vdvsd_8_bit_priority_encoder___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vdvsd_8_bit_priority_encoder__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vdvsd_8_bit_priority_encoder___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->en = VL_RAND_RESET_I(1);
    vlSelf->in = VL_RAND_RESET_I(8);
    vlSelf->eno = VL_RAND_RESET_I(1);
    vlSelf->gs = VL_RAND_RESET_I(1);
    vlSelf->out = VL_RAND_RESET_I(3);
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out1 = 0;
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out2 = 0;
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out3 = 0;
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out4 = 0;
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out5 = 0;
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out6 = 0;
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out7 = 0;
    vlSelf->dvsd_8_bit_priority_encoder__DOT__out__out__out8 = 0;
}
