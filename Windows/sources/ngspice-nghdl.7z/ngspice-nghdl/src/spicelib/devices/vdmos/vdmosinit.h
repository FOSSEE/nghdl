#ifndef _VDMOSINIT_H
#define _VDMOSINIT_H

extern IFparm VDMOSpTable[ ];
extern IFparm VDMOSmPTable[ ];
extern char *VDMOSnames[ ];
extern int VDMOSpTSize;
extern int VDMOSmPTSize;
extern int VDMOSnSize;
extern int VDMOSiSize;
extern int VDMOSmSize;

#endif
