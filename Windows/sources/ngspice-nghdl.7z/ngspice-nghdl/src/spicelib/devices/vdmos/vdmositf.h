/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_VDMOS
#define DEV_VDMOS

extern SPICEdev *get_vdmos_info(void);

#endif
