#ifndef _B3SOIDDINIT_H
#define _B3SOIDDINIT_H

extern IFparm B3SOIDDpTable[];
extern IFparm B3SOIDDmPTable[];
extern char *B3SOIDDnames[];
extern int B3SOIDDpTSize;
extern int B3SOIDDmPTSize;
extern int B3SOIDDnSize;
extern int B3SOIDDiSize;
extern int B3SOIDDmSize;

#endif
