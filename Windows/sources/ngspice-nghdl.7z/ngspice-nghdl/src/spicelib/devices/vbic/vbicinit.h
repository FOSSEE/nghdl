#ifndef _VBICINIT_H
#define _VBICINIT_H

extern IFparm VBICpTable[ ];
extern IFparm VBICmPTable[ ];
extern char *VBICnames[ ];
extern int VBICpTSize;
extern int VBICmPTSize;
extern int VBICnSize;
extern int VBICiSize;
extern int VBICmSize;

#endif
