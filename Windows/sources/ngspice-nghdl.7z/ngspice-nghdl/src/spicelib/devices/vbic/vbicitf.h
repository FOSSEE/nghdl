/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1985 Thomas L. Quarles
Model Author: 1995 Colin McAndrew Motorola
Spice3 Implementation: 2003 Dietmar Warning DAnalyse GmbH
**********/
#ifndef DEV_VBIC
#define DEV_VBIC

extern SPICEdev *get_vbic_info(void);

#endif
