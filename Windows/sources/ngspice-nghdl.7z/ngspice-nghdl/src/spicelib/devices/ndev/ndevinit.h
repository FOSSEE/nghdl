#ifndef _NDEVINIT_H
#define _NDEVINIT_H

extern IFparm NDEVpTable[ ];
extern IFparm NDEVmPTable[ ];
extern char *NDEVnames[ ];
extern int NDEVpTSize;
extern int NDEVmPTSize;
extern int NDEVnSize;
extern int NDEViSize;
extern int NDEVmSize;

#endif
