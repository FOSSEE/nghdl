/**********
Copyright 1991 Regents of the University of California.  All rights reserved.
**********/

#ifndef DEV_NDEV
#define DEV_NDEV

extern SPICEdev *get_ndev_info(void);

#endif
