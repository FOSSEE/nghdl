#ifndef _HSMHV2INIT_H
#define _HSMHV2INIT_H

extern IFparm HSMHV2pTable[ ];
extern IFparm HSMHV2mPTable[ ];
extern char *HSMHV2names[ ];
extern int HSMHV2pTSize;
extern int HSMHV2mPTSize;
extern int HSMHV2nSize;
extern int HSMHV2iSize;
extern int HSMHV2mSize;

#endif
