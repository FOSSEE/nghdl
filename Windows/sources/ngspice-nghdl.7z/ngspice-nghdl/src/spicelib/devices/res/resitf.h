/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_RES
#define DEV_RES

SPICEdev *get_res_info(void);

#endif
