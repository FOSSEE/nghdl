#ifndef _BSIM4v7INIT_H
#define _BSIM4v7INIT_H

extern IFparm BSIM4v7pTable[ ];
extern IFparm BSIM4v7mPTable[ ];
extern char *BSIM4v7names[ ];
extern int BSIM4v7pTSize;
extern int BSIM4v7mPTSize;
extern int BSIM4v7nSize;
extern int BSIM4v7iSize;
extern int BSIM4v7mSize;

#endif
