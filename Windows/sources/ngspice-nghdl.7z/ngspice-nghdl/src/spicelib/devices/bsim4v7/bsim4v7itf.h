/**********
Copyright 2004 Regents of the University of California.  All rights reserved.
Author: 2000 Weidong Liu.
Author: 2001- Xuemei Xi
File: bsim4v7itf.h
**********/

#ifndef DEV_BSIM4v7
#define DEV_BSIM4v7

SPICEdev *get_bsim4v7_info(void);

#endif
