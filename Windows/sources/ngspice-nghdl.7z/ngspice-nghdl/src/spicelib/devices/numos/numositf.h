/**********
Copyright 1991 Regents of the University of California.  All rights reserved.
**********/

#ifndef DEV_NUMOS
#define DEV_NUMOS

extern SPICEdev *get_numos_info(void);

#endif
