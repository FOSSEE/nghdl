#ifndef _NUMOSINIT_H
#define _NUMOSINIT_H

extern IFparm NUMOSpTable[ ];
extern IFparm NUMOSmPTable[ ];
extern char *NUMOSnames[ ];
extern int NUMOSpTSize;
extern int NUMOSmPTSize;
extern int NUMOSnSize;
extern int NUMOSiSize;
extern int NUMOSmSize;

#endif
