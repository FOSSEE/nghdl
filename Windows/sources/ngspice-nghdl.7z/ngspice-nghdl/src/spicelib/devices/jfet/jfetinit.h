#ifndef _JFETINIT_H
#define _JFETINIT_H

extern IFparm JFETpTable[ ];
extern IFparm JFETmPTable[ ];
extern char *JFETnames[ ];
extern int JFETpTSize;
extern int JFETmPTSize;
extern int JFETnSize;
extern int JFETiSize;
extern int JFETmSize;

#endif
