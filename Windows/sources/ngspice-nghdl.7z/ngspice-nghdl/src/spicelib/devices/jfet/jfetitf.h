/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_JFET
#define DEV_JFET

SPICEdev *get_jfet_info(void);

#endif
