#ifndef _ASRCINIT_H
#define _ASRCINIT_H

extern IFparm ASRCpTable[];
extern char *ASRCnames[];
extern int ASRCpTSize;
extern int ASRCnSize;
extern int ASRCiSize;
extern int ASRCmSize;

#endif
