/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/

#ifndef DEV_ASRC
#define DEV_ASRC

extern SPICEdev *get_asrc_info(void);

#endif
