#ifndef _CKTACCEPT_H
#define _CKTACCEPT_H


#endif
