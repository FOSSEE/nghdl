#ifndef _NBJT2INIT_H
#define _NBJT2INIT_H

extern IFparm NBJT2pTable[ ];
extern IFparm NBJT2mPTable[ ];
extern char *NBJT2names[ ];
extern int NBJT2pTSize;
extern int NBJT2mPTSize;
extern int NBJT2nSize;
extern int NBJT2iSize;
extern int NBJT2mSize;

#endif
