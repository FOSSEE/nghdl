/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_SW
#define DEV_SW

extern SPICEdev *get_sw_info(void);

#endif
