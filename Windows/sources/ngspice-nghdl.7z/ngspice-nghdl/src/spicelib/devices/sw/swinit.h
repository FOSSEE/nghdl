#ifndef _SWINIT_H
#define _SWINIT_H

extern IFparm SWpTable[];
extern IFparm SWmPTable[];
extern char *SWnames[];
extern int SWpTSize;
extern int SWmPTSize;
extern int SWnSize;
extern int SWiSize;
extern int SWmSize;

#endif
