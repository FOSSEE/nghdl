/**********
Copyright 2004 Regents of the University of California.  All rights reserved.
Author: 2000 Weidong Liu.
Author: 2001- Xuemei Xi
File: bsim4v6itf.h
**********/

#ifndef DEV_BSIM4v6
#define DEV_BSIM4v6

SPICEdev *get_bsim4v6_info(void);

#endif
