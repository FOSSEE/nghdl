#!/bin/sh

exec wish vspicechart.tcl example.cir
