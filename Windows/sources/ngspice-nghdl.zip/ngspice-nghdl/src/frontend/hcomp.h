#ifndef ngspice_HCOMP_H
#define ngspice_HCOMP_H


int hcomp(const void *a, const void *b);

#endif
