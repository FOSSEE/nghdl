/*************
 * Header file for dotcards.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_DOTCARDS_H
#define ngspice_DOTCARDS_H

wordlist *gettoks(char *s);


#endif
