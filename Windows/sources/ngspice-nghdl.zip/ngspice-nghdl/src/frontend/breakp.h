/*************
 * Header file for breakp.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_BREAKP_H
#define ngspice_BREAKP_H

void com_stop(wordlist *wl);
void com_trce(wordlist *wl);
void com_iplot(wordlist *wl);
void com_step(wordlist *wl);
void com_sttus(wordlist *wl);
void com_delete(wordlist *wl);
void ft_trquery(void);




#endif
