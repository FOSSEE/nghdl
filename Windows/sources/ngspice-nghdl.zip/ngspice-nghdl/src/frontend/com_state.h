#ifndef ngspice_COM_STATE_H
#define ngspice_COM_STATE_H

void com_state(wordlist *wl);

#endif

