#ifndef ngspice_COM_AHELP_H
#define ngspice_COM_AHELP_H


void com_ahelp(wordlist *wl);

#endif
