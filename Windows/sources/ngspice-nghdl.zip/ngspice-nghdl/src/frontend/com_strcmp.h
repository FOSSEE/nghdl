#ifndef ngspice_COM_STRCMP_H
#define ngspice_COM_STRCMP_H


void com_strcmp(wordlist *wl);

#endif
