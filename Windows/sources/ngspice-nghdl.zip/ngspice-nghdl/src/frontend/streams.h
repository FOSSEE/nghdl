/*************
* Header file for streams.c
************/

#ifndef ngspice_STREAMS_H
#define ngspice_STREAMS_H

#include "ngspice/bool.h"
#include "ngspice/wordlist.h"

void fixdescriptors(void);

#endif
