/*************
* Header file for com_shift.c
************/

#ifndef ngspice_COM_SHIFT_H
#define ngspice_COM_SHIFT_H

void com_shift(wordlist *wl);

#endif
