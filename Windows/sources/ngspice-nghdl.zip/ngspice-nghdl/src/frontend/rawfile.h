/*************
 * Header file for rawfile.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_RAWFILE_H
#define ngspice_RAWFILE_H




#endif
