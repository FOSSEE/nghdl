#ifndef ngspice_PVEC_H
#define ngspice_PVEC_H

#include "ngspice/dvec.h"

void pvec(struct dvec *d);

#endif
