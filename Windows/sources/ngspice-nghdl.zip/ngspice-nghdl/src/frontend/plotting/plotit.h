#ifndef ngspice_PLOTIT_H
#define ngspice_PLOTIT_H

bool plotit(wordlist *wl, char *hcopy, char *devname);

#endif
