#ifndef ngspice_PLOTTING_H
#define ngspice_PLOTTING_H

#include "ngspice/plot.h"

extern struct plot constantplot;

#endif
