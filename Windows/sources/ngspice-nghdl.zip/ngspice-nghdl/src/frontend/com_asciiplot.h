#ifndef ngspice_COM_ASCIIPLOT_H
#define ngspice_COM_ASCIIPLOT_H

void com_asciiplot(wordlist *wl);

#endif

