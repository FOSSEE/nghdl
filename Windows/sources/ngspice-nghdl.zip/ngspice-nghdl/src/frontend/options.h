/*************
 * Header file for options.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_OPTIONS_H
#define ngspice_OPTIONS_H



#endif
