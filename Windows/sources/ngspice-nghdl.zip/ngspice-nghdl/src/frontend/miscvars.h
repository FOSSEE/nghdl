/*************
 * Header file for miscvars.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_MISCVARS_H
#define ngspice_MISCVARS_H




#endif
