/*************
 * Header file for backq.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_BACKQ_H
#define ngspice_BACKQ_H


#endif
