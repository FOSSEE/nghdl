/*************
* Header file for com_shell.c
************/

#ifndef ngspice_COM_SHELL_H
#define ngspice_COM_SHELL_H

void com_shell(wordlist *wl);

#endif
