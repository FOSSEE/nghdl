/*************
 * Header file for linear.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_LINEAR_H
#define ngspice_LINEAR_H

void com_linearize(wordlist *wl);


#endif
