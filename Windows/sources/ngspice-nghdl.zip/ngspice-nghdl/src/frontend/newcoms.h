/*************
 * Header file for newcoms.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_NEWCOMS_H
#define ngspice_NEWCOMS_H

void com_reshape(wordlist *wl);


#endif
