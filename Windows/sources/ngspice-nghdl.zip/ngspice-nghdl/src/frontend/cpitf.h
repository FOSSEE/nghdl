/*************
 * Header file for cpitf.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_CPITF_H
#define ngspice_CPITF_H



#endif
