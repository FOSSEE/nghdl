#ifndef ngspice_COMMANDS_H
#define ngspice_COMMANDS_H


extern struct comm spcp_coms[];
extern struct comm nutcp_coms[];

#endif
