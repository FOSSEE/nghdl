#ifndef ngspice_COM_DUMP_H
#define ngspice_COM_DUMP_H

void com_dump(wordlist *wl);

#endif
