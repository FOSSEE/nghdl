/*************
 * Header file for diff.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_DIFF_H
#define ngspice_DIFF_H

#include "ngspice/wordlist.h"


void com_diff(wordlist *wl);

#endif
