/*************
 * Header file for nutinp.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_NUTINP_H
#define ngspice_NUTINP_H

void nutinp_source(char *file);



#endif
