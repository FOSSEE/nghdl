#!/bin/sh
gcc -c ghdlserver.c
ghdl -a Utility_Package.vhdl && 
ghdl -a Vhpi_Package.vhdl &&
ghdl -a inverter.vhdl &&
ghdl -a inverter_tb.vhdl  &&
ghdl -e -Wl,ghdlserver.o -Wl,libws2_32.a inverter_tb &&
./inverter_tb.exe

