// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include <Windows.h>
#include "7zip/Bundles/Nsis7z/pluginapi.h"

#endif
