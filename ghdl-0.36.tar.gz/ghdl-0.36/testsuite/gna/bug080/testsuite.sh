#! /bin/sh

. ../../testenv.sh

analyze_failure impurefunc.vhdl

clean

echo "Test successful"
