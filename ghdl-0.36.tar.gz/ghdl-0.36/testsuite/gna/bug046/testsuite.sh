#! /bin/sh

. ../../testenv.sh

analyze bug_pkg.vhdl

clean

echo "Test successful"
