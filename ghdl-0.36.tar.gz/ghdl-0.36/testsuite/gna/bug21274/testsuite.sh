#! /bin/sh

. ../../testenv.sh

analyze 21274.vhd

clean

echo "Test successful"
