#! /bin/sh

. ../../testenv.sh

analyze failure.vhdl
clean

echo "Test successful"
