#! /bin/sh

# Need cocotb
# Was run with:
# make COCOTB=/path/to/cocotb/ SIM=ghdl ARCH=x86_64 PYTHON_BIN=python TOPLEVEL_LANG=vhdl CMD=$GHDL

echo "Test skipped"
