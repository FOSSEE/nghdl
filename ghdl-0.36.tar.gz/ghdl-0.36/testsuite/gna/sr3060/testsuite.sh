#! /bin/sh

. ../../testenv.sh

analyze_failure integer_class.vhdl

clean

echo "Test successful"
