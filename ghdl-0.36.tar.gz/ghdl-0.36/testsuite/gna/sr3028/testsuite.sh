#! /bin/sh

. ../../testenv.sh

analyze_failure vc.vhdl

clean

echo "Test successful"
