#! /bin/sh

. ../../testenv.sh

analyze test.vhdl

clean

echo "Test successful"
