#! /bin/sh

. ../../testenv.sh

# FIXME
#analyze tests.vhd
# elab_simulate tests

clean

echo "Test successful"
