#! /bin/sh

. ../../testenv.sh

$GHDL --bug-box || true

echo "Test successful"
