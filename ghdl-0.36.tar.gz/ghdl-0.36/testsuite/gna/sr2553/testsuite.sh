#! /bin/sh

. ../../testenv.sh

analyze_failure 2553.vhd

clean

echo "Test successful"
