#! /bin/sh

. ../../testenv.sh

analyze_failure testcase.vhdl

clean

echo "Test successful"
