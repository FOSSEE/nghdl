.. _CHANGE:Roadmap:

Roadmap | Future Improvements
#############################

We have several axes for `GHDL` improvements:

* Documentation
* Better diagnostics messages (warning and error)
* Full support of VHDL-2008
* Optimization (simulation speed)
* Graphical tools (to see waves and to debug)
* Style checks
* VITAL acceleration

