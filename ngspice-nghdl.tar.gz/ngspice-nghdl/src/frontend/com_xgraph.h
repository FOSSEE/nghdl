#ifndef ngspice_COM_XGRAPH_H
#define ngspice_COM_XGRAPH_H

void com_xgraph(wordlist *wl);

#endif
