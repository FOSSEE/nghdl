/*************
 * Header file for mktemp.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_MKTEMP_H
#define ngspice_MKTEMP_H

char * smktemp(char *id);

#endif
