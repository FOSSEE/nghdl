/*************
 * Header file for dup2.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_DUP2_H
#define ngspice_DUP2_H

#ifndef HAVE_DUP2

dup2(int oldd, int newd);

#endif

#endif
