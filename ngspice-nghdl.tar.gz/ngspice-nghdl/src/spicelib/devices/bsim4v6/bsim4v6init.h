#ifndef _BSIM4v6INIT_H
#define _BSIM4v6INIT_H

extern IFparm BSIM4v6pTable[ ];
extern IFparm BSIM4v6mPTable[ ];
extern char *BSIM4v6names[ ];
extern int BSIM4v6pTSize;
extern int BSIM4v6mPTSize;
extern int BSIM4v6nSize;
extern int BSIM4v6iSize;
extern int BSIM4v6mSize;

#endif
