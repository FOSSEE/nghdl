/**********
Copyright 1991 Regents of the University of California.  All rights reserved.
**********/

#ifndef DEV_NUMD
#define DEV_NUMD

extern SPICEdev *get_numd_info(void);

#endif
