#ifndef _MESAINIT_H
#define _MESAINIT_H

extern IFparm MESApTable[ ];
extern IFparm MESAmPTable[ ];
extern char *MESAnames[ ];
extern int MESApTSize;
extern int MESAmPTSize;
extern int MESAnSize;
extern int MESAiSize;
extern int MESAmSize;

#endif
