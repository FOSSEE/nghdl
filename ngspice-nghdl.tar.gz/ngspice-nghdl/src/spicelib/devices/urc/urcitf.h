/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_URC
#define DEV_URC

extern SPICEdev *get_urc_info(void);

#endif
