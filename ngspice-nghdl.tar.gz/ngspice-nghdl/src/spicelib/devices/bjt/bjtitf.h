/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_BJT
#define DEV_BJT

extern SPICEdev *get_bjt_info(void);


#endif
