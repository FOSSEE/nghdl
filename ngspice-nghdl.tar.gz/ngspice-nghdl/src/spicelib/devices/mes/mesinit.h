#ifndef _MESINIT_H
#define _MESINIT_H

extern IFparm MESpTable[ ];
extern IFparm MESmPTable[ ];
extern char *MESnames[ ];
extern int MESpTSize;
extern int MESmPTSize;
extern int MESnSize;
extern int MESiSize;
extern int MESmSize;

#endif
