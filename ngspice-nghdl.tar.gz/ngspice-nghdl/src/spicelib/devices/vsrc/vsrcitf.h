/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_VSRC
#define DEV_VSRC

extern SPICEdev *get_vsrc_info(void);

#endif
