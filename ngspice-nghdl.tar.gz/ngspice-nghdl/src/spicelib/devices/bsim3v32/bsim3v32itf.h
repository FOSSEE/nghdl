/**********
Copyright 1999 Regents of the University of California.  All rights reserved.
Author: 1991 JianHui Huang and Min-Chie Jeng.
Modified by Paolo Nenzi 2002
File: bsim3itf.h
**********/

#ifndef DEV_BSIM3v32
#define DEV_BSIM3v32

SPICEdev *get_bsim3v32_info(void);

#endif
