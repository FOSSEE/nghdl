
#ifndef DEV_HISIM2
#define DEV_HISIM2

SPICEdev *get_hsm2_info(void);

#endif
