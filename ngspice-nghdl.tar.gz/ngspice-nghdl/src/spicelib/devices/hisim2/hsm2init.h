#ifndef _HISIM2INIT_H
#define _HISIM2INIT_H

extern IFparm HSM2pTable[ ];
extern IFparm HSM2mPTable[ ];
extern char *HSM2names[ ];
extern int HSM2pTSize;
extern int HSM2mPTSize;
extern int HSM2nSize;
extern int HSM2iSize;
extern int HSM2mSize;

#endif
