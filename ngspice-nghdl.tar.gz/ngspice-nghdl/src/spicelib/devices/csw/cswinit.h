#ifndef _CSWINIT_H
#define _CSWINIT_H

extern IFparm CSWpTable[];
extern IFparm CSWmPTable[];
extern char *CSWnames[];
extern int CSWpTSize;
extern int CSWmPTSize;
extern int CSWnSize;
extern int CSWiSize;
extern int CSWmSize;

#endif
