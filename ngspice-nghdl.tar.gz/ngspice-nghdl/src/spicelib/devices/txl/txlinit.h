/**********
Copyright 1992 Regents of the University of California.  All rights
reserved.
Author: 1992 Charles Hough
**********/
#ifndef _TXLINIT_H
#define _TXLINIT_H

extern IFparm TXLpTable[ ];
extern IFparm TXLmPTable[ ];
extern int TXLmPTSize;
extern int TXLpTSize;
extern char *TXLnames[ ];
extern int TXLiSize;
extern int TXLmSize;
extern int TXLnSize;

#endif
