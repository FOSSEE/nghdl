/**********
Copyright 1999 Regents of the University of California.  All rights reserved.
Author: 1998 Samuel Fung
File: b3soifditf.h
**********/
#ifndef DEV_B3SOIFD
#define DEV_B3SOIFD

#include "b3soifdext.h"

SPICEdev *get_b3soifd_info (void);

#endif

