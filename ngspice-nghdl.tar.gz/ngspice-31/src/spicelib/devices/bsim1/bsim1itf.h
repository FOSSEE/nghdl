/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_BSIM1
#define DEV_BSIM1

SPICEdev *get_bsim1_info(void);

#endif
