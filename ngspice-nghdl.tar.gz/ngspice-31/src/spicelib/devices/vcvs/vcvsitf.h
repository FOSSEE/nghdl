/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_VCVS
#define DEV_VCVS

SPICEdev *get_vcvs_info(void);

#endif
