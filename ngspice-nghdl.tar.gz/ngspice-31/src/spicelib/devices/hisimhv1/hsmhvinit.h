#ifndef _HISIMINIT_H
#define _HISIMINIT_H

extern IFparm HSMHVpTable[ ];
extern IFparm HSMHVmPTable[ ];
extern char *HSMHVnames[ ];
extern int HSMHVpTSize;
extern int HSMHVmPTSize;
extern int HSMHVnSize;
extern int HSMHViSize;
extern int HSMHVmSize;

#endif
