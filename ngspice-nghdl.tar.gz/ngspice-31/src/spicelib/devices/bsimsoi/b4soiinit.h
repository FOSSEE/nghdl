#ifndef _B4SOIINIT_H
#define _B4SOIINIT_H

extern IFparm B4SOIpTable[];
extern IFparm B4SOImPTable[];
extern char *B4SOInames[];
extern int B4SOIpTSize;
extern int B4SOImPTSize;
extern int B4SOInSize;
extern int B4SOIiSize;
extern int B4SOImSize;

#endif
