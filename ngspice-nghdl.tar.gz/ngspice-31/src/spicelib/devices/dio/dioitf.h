/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_DIO
#define DEV_DIO

extern SPICEdev *get_dio_info(void);

#endif
