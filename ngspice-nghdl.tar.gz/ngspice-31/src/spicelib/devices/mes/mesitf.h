/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_MES
#define DEV_MES

SPICEdev *get_mes_info(void);

#endif
