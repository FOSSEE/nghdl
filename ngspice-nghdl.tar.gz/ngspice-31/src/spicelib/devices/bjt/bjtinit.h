#ifndef _BJTINIT_H
#define _BJTINIT_H

extern IFparm BJTpTable[ ];
extern IFparm BJTmPTable[ ];
extern char *BJTnames[ ];
extern int BJTpTSize;
extern int BJTmPTSize;
extern int BJTnSize;
extern int BJTiSize;
extern int BJTmSize;

#endif
