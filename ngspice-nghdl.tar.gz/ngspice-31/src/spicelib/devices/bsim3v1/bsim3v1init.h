#ifndef _BSIM3v1INIT_H
#define _BSIM3v1INIT_H

extern IFparm BSIM3v1pTable[ ];
extern IFparm BSIM3v1mPTable[ ];
extern char *BSIM3v1names[ ];
extern int BSIM3v1pTSize;
extern int BSIM3v1mPTSize;
extern int BSIM3v1nSize;
extern int BSIM3v1iSize;
extern int BSIM3v1mSize;

#endif
