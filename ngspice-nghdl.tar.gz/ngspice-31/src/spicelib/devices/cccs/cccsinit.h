#ifndef _CCCSINIT_H
#define _CCCSINIT_H

extern IFparm CCCSpTable[ ];
extern char *CCCSnames[ ];
extern int CCCSpTSize;
extern int CCCSnSize;
extern int CCCSiSize;
extern int CCCSmSize;

#endif
