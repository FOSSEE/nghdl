#ifndef DEV_CPL
#define DEV_CPL

SPICEdev *get_cpl_info(void);

#endif
