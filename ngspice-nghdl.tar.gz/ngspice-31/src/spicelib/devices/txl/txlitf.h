/**********
Copyright 1992 Regents of the University of California.  All rights
reserved.
Author: 1992 Charles Hough
**********/

#ifndef DEV_TXL
#define DEV_TXL

SPICEdev *get_txl_info(void);

#endif
