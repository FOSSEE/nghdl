/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_CCVS
#define DEV_CCVS

SPICEdev *get_ccvs_info(void);

#endif
