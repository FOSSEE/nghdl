/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
**********/
#ifndef DEV_MESA
#define DEV_MESA

SPICEdev *get_mesa_info(void);

#endif
