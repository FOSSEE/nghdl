/*************
 * Header file for printnum.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_PRINTNUM_H
#define ngspice_PRINTNUM_H

void printnum(char * buf, double num);

#endif
