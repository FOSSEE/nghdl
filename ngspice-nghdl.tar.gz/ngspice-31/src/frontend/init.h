#ifndef ngspice_INIT_H
#define ngspice_INIT_H



#endif
