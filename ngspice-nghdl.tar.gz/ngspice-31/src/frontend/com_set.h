#ifndef ngspice_COM_SET_H
#define ngspice_COM_SET_H

void com_set(wordlist *wl);

#endif
