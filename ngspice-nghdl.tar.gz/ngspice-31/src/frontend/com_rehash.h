/*************
* Header file for com_rehsh.c
************/

#ifndef ngspice_COM_REHASH_H
#define ngspice_COM_REHASH_H

#include "ngspice/wordlist.h"

void com_rehash(wordlist *wl);

#endif
