#ifndef ngspice_COM_HELP_H
#define ngspice_COM_HELP_H


void com_help(wordlist *wl);

#endif

