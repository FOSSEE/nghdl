/*************
 * Header file for input.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_INPUT_H
#define ngspice_INPUT_H


int input(FILE *fp);


#endif
