/*************
 * Header file for unixcom.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_UNIXCOM_H
#define ngspice_UNIXCOM_H


#endif
