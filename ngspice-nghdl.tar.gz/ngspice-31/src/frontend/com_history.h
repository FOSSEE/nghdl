/*************
 * Header file for history.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_COM_HISTORY_H
#define ngspice_COM_HISTORY_H

void com_history(wordlist *wl);



#endif
