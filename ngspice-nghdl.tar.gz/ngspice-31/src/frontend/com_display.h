#ifndef ngspice_COM_DISPLAY_H
#define ngspice_COM_DISPLAY_H

#include "ngspice/wordlist.h"

void com_display(wordlist *wl);

#endif
