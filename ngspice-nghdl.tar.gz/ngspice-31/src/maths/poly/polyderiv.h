#ifndef ngspice_POLYDERIV_H
#define ngspice_POLYDERIV_H

void ft_polyderiv(double *coeffs, int degree);

#endif
